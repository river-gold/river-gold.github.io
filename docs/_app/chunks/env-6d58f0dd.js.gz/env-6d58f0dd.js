const s=!0;export{s as b};
