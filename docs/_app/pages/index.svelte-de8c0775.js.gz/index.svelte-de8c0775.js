import{S as r,i as c,s as l,t as d,F as i,d as a,h,g as u,E as s}from"../chunks/index-1071a69b.js";import{b as m}from"../chunks/env-6d58f0dd.js";function _(n){let t;return{c(){t=d(`

\uD648`),this.h()},l(e){i('[data-svelte="svelte-1qlo5v2"]',document.head).forEach(a),t=h(e,`

\uD648`),this.h()},h(){document.title="Home"},m(e,o){u(e,t,o)},p:s,i:s,o:s,d(e){e&&a(t)}}}const x=m,v=!0;class q extends r{constructor(t){super(),c(this,t,null,_,l,{})}}export{q as default,v as prerender,x as router};
